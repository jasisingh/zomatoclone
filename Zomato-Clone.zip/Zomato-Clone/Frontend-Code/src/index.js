import React from 'react';
import ReactDOM from 'react-dom';
import 'bootstrap/dist/css/bootstrap.css';
import Router from './Components/Router';


ReactDOM.render(<Router/>, document.getElementById('root'));